Please cite this project as follows:

Meaghan Fowlie (2022),  miniassignment autograder - version 0.1.1. url: github.com/megodoonch/miniassignment-autograder
